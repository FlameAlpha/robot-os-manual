/*
 * saveData.h
 *
 *  Created on: 2017年10月18日
 *      Author: hanbing
 */

#ifndef INCLUDE_SAVEDATA_H_
#define INCLUDE_SAVEDATA_H_
/*打开文件
 * */
extern int openFile();

/*关闭文件
 * */
extern int closeFile();

/*保持数据到队列
 * data 存放数据
 * cow 数据个数
 * return 0 right -1 队列已满
 * */
extern int  saveData(double* data, int cow );

//保持数据线程
extern void* saveDataToFile(void* arg);


#endif /* INCLUDE_SAVEDATA_H_ */

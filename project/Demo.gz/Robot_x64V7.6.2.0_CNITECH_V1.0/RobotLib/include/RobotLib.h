/*
 * RobotLib.h
 *
 *  Created on: 2018-5-2
 *      Author: hanbing
 */

#ifndef ROBOTLIB_H_
#define ROBOTLIB_H_
#include "RobotEtherCAT.h"
#include "RobotInterface.h"
#include "robotStruct.h"
#include <unistd.h>
extern char* EC_deviceName[2];
extern int torqueTimerE(int index);
extern int initSHARE_DATA();
extern void initTimer(int flag);
extern void* ecTimer(void* arg);
extern int initPriority();

extern void init_command_arg(command_arg* arg);
extern int commandLineParser(int argc, char *argv[],command_arg* arg);


/*system initialize
 * robot_flag:  select robot ,0: get from configure file;1:sia; 2:ur
 * path: configure file path
 *
 * return 0:ritgth; other: wrong
 * */
extern int rob_initialize(int robot_flag, char* path);

/*system initialize
 * arg: input parmeter
 *
 * return 0:ritgth; other: wrong
 * */
extern int system_initialize(command_arg* arg);

/*move robot by joint space
 * rjoint: target position(joint)
 * rspeed: move speed
 * rzone: area of turning
 * rtool: tool
 * rwobj: coordinate system
 * */
extern void moveA(robjoint* rjoint, speed* rspeed, zone* rzone, tool* rtool, wobj* rwobj);

/*move dual-robot by joint space
 * robot1---
 * rjoint1: target position(joint)
 * rspeed1: move speed
 * rzone1: area of turning
 * rtool1: tool
 * rwobj1: coordinate system
 * robot2---
 * rjoint2: target position(joint)
 * rspeed2: move speed
 * rzone2: area of turning
 * rtool2: tool
 * rwobj2: coordinate system
 *
 * */
extern void dual_moveA(robjoint* rjoint1,robjoint* rjoint2, speed* rspeed1,speed* rspeed2, zone* rzone1, zone* rzone2, tool* rtool1, tool* rtool2, wobj* rwobj1, wobj* rwobj2);

/*move robot by joint space
 * rjoint: target position(joint)
 * rspeed: move speed
 * rzone: area of turning
 * rtool: tool
 * rwobj: coordinate system
 *_index: robot index
 * */
extern void multi_moveA(robjoint* rjoint, speed* rspeed, zone* rzone, tool* rtool, wobj* rwobj, int _index);

/*move robot by joint space
 * rpose: target position(pose)
 * rspeed: move speed
 * rzone: area of turning
 * rtool: tool
 * rwobj: coordinate system
 * */
extern void moveJ(robpose* rpose, speed* rspeed, zone* rzone, tool* rtool, wobj* rwobj);

/*move dual-robot by joint space
 * robot1---
 * rpose1: target position(pose)
 * rspeed1: move speed
 * rzone1: area of turning
 * rtool1: tool
 * rwobj1: coordinate system
 * robot2---
 * rpose2: target position(pose)
 * rspeed2: move speed
 * rzone2: area of turning
 * rtool2: tool
 * rwobj2: coordinate system
 *
 * */
extern void dual_moveJ(robpose* rpose1,robpose* rpose2, speed* rspeed1,speed* rspeed2, zone* rzone1, zone* rzone2, tool* rtool1, tool* rtool2, wobj* rwobj1, wobj* rwobj2);

/*move robot by joint space
 * rpose: target position(pose)
 * rspeed: move speed
 * rzone: area of turning
 * rtool: tool
 * rwobj: coordinate system
 *_index: robot index
 * */
extern void multi_moveJ(robpose* rpose, speed* rspeed, zone* rzone, tool* rtool, wobj* rwobj, int _index);

/*move robot  in a straight line
 * rpose: target position(pose)
 * rspeed: move speed
 * rzone: area of turning
 * rtool: tool
 * rwobj: coordinate system
 * */
extern void moveL(robpose* rpose, speed* rspeed, zone* rzone, tool* rtool, wobj* rwobj);

/*move dual-robot in a straight line
 * robot1---
 * rpose1: target position(pose)
 * rspeed1: move speed
 * rzone1: area of turning
 * rtool1: tool
 * rwobj1: coordinate system
 * robot2---
 * rpose2: target position(pose)
 * rspeed2: move speed
 * rzone2: area of turning
 * rtool2: tool
 * rwobj2: coordinate system
 *
 * */
extern void dual_moveL(robpose* rpose1,robpose* rpose2, speed* rspeed1,speed* rspeed2, zone* rzone1, zone* rzone2, tool* rtool1, tool* rtool2, wobj* rwobj1, wobj* rwobj2);

/*move robot  in a straight line
 * rpose: target position(pose)
 * rspeed: move speed
 * rzone: area of turning
 * rtool: tool
 * rwobj: coordinate system
 *_index: robot index
 * */
extern void multi_moveL(robpose* rpose, speed* rspeed, zone* rzone, tool* rtool, wobj* rwobj, int _index);

/*move robot  in a circular arc
 * rpose: target position(pose)
 * rpose_mid: middle position
 * rspeed: move speed
 * rzone: area of turning
 * rtool: tool
 * rwobj: coordinate system
 * */
extern void moveC(robpose* rpose, robpose* rpose_mid, speed* rspeed, zone* rzone, tool* rtool, wobj* rwobj);

/*move dual-robot in a straight line
 * robot1---
 * rpose1: target position(pose)
 * rpose_mid1: middle position
 * rspeed1: move speed
 * rzone1: area of turning
 * rtool1: tool
 * rwobj1: coordinate system
 * robot2---
 * rpose2: target position(pose)
 * rpose_mid2: middle position
 * rspeed2: move speed
 * rzone2: area of turning
 * rtool2: tool
 * rwobj2: coordinate system
 *
 * */
extern void dual_moveC(robpose* rpose1,robpose* rpose2, robpose* rpose_mid1, robpose* rpose_mid2, speed* rspeed1,speed* rspeed2, zone* rzone1, zone* rzone2, tool* rtool1, tool* rtool2, wobj* rwobj1, wobj* rwobj2);

/*move robot  in a circular arc
 * rpose: target position(pose)
 * rpose_mid: middle position
 * rspeed: move speed
 * rzone: area of turning
 * rtool: tool
 * rwobj: coordinate system
 *_index: robot index
 * */
extern void multi_moveC(robpose* rpose, robpose* rpose_mid, speed* rspeed, zone* rzone, tool* rtool, wobj* rwobj, int _index);

/*move robot  in a spiral line
 * rpose: target position(pose)
 * rpose_mid: middle position
 * rspeed: move speed
 * rzone: area of turning
 * rtool: tool
 * rwobj: coordinate system
 * */
extern void moveT(robpose* rpose, robpose* rpose_mid, speed* rspeed, zone* rzone, tool* rtool, wobj* rwobj);

/*move dual-robot in a spiral line
 * robot1---
 * rpose1: target position(pose)
 * rpose_mid1: middle position
 * rspeed1: move speed
 * rzone1: area of turning
 * rtool1: tool
 * rwobj1: coordinate system
 * robot2---
 * rpose2: target position(pose)
 * rpose_mid2: middle position
 * rspeed2: move speed
 * rzone2: area of turning
 * rtool2: tool
 * rwobj2: coordinate system
 *
 * */
extern void dual_moveT(robpose* rpose1,robpose* rpose2, robpose* rpose_mid1, robpose* rpose_mid2, speed* rspeed1,speed* rspeed2, zone* rzone1, zone* rzone2, tool* rtool1, tool* rtool2, wobj* rwobj1, wobj* rwobj2);

/*move robot  in a spiral line
 * rpose: target position(pose)
 * rpose_mid: middle position
 * rspeed: move speed
 * rzone: area of turning
 * rtool: tool
 * rwobj: coordinate system
 *_index: robot index
 * */
extern void multi_moveT(robpose* rpose, robpose* rpose_mid, speed* rspeed, zone* rzone, tool* rtool, wobj* rwobj, int _index);

/*B spline move in joint space
 * filename Necessary points sequence data filename
 * rspeed velocity (time)
 * rtool tool
 * rwobj  coordinate system
 * */
extern void moveAJBS(char* filename, speed* rspeed, tool* rtool, wobj* rwobj);

/*dual-robot B spline move in joint space
 * robot1---
 * filename1: data file
 * rspeed1: move speed
 * rtool1: tool
 * rwobj1: coordinate system
 * robot2---
 * filename2: data file
 * rspeed2: move speed
 * rtool2: tool
 * rwobj2: coordinate system
 *
 * */
extern void dual_moveAJBS(char* filename1, char* filename2, speed* rspeed1, speed* rspeed2, tool* rtool1, tool* rtool2, wobj* rwobj1, wobj* rwobj2);

/*B spline move in joint space
 * filename Necessary points sequence data filename
 * rspeed velocity (time)
 * rtool tool
 * rwobj  coordinate system
 * _index robot index
 * */
extern void multi_moveAJBS(char* filename, speed* rspeed, tool* rtool, wobj* rwobj, int _index);

/*start move initialize or power
 * */
extern void move_start();

/*stop move or poweroff
 * */
extern void move_stop();




/////////////////////////////////////////////////////////////////////////////////////////

/*get joint data by name of the data
 *J: data name
 *rjoint: joint data
 *_index: robot index
 *
 * return 1:right other:wrong
 * */
extern int getrobjoint2(char* J, robjoint* rjoint, int _index);

/*get joint data by name of the data
 *J: data name
 *rjoint: joint data
 *
 * return 1:right other:wrong
 * */
extern int getrobjoint(char* J, robjoint* rjoint);


/*get pose data by name of the data
 *P: data name
 *rpose: pose data
 *
 * return 1:right other:wrong
 * */
extern int getrobpose(char* P, robpose* rpose);

/*get speed data by name of the data
 * S: data name
 * sp: speed data
 * _index: robot index
 *
 * return 1:right other:wrong
 * */
extern int getspeed2(char* S, speed* sp, int _index);

/*get speed data by name of the data
 * S: data name
 * sp: speed data
 *
 * return 1:right other:wrong
 * */
extern int getspeed(char* S, speed* sp);

/*get zone data by name of the data
 * Z: data name
 * zo: zone data
 *
 * return 1:right other:wrong
 * */
extern int getzone(char* Z, zone* zo);

/*get tool data by name of the data
 *T: data name
 *to: tool data
 *
 * return 1:right other:wrong
 * */
extern int gettool(char* T, tool* to);

/*get wobj data by name of the data
 * w: data name
 * wo: wobj data
 *
 * return 1:right other:wrong
 * */
extern int getwobj(char* W, wobj* wo);

/*get robot current joint
 * joint: current joint data
 * _index: robot index
 * */
extern void getRobotJoint(double* joint, int _index);

/*get robot current pose
 * pospose: current pose data
 * _index: robot index
 * */
extern void getPosAndPose(double* pospose, int _index);

/*sleep
 * _time time (s)  resolution ratio ms
 * */
extern void RSleep(double _time);

/*sleep
 * _time time (s)  resolution ratio ms
 * */
extern void RSleep2(double _time);

/*set robot move the percentage of the acceleration and jerk
 * a: acceleration
 * aa: jerk
 * */
extern void AccSet(int a, int aa);

/*set do
 * id: do index
 * flag: 0 or 1
 * */
extern void SetDo(int id,int flag);

/*get do
 * id: do index
 * flag: return 0 or 1
 * */
extern void GetDi(int id,int* flag);

/*wait di
 * di :di
 * value: 0 or 1
 * */
extern void WaitDi(int di, int value);

/*set ao
 * id: ao index
 * flag: ao value
 * */
extern void SetAo(int id,double flag);

/*get ao
 * id: ao index
 * flag: return ao value
 * */
extern void GetAi(int id,double* flag);

/*get offset position
 * rpose: positon
 * x: offset x value
 * y: offset y value
 * z: offset z value
 * k: offset roll
 * p: offset pitch
 * s: offset yaw
 *
 * return offset position
 * */
extern robpose Offs(const robpose* rpose, double x, double y, double z, double k, double p, double s);

//----------------------------------------------------------------------------------------communication interface--------------------------------------------------------------------------
/*create socket server
 * ip: ip
 * port: port
 * sName: server name
 *
 * return 1:right other:wrong
 * */
extern int SocketCreate(char* ip, int port, char* sName);

/*create socket client
 * ip: ip
 * port: port
 * sName: client name
 *
 * return 1:right other:wrong
 * */
extern int ClientCreate(char* ip, int port, char* sName);

/*close socket server or client
 * sName: server or client name
 *
 * return 1:right other:wrong
 * */
extern int SocketClose(char* sName);

/*sent byte
 * data: byte data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int SocketSendByte(int data, char* sName);

/*receive byte
 * data: return byte data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int SocketRecvByte(int* data, char* sName);

/*sent string
 * data: string data
 * sName: socket name
 *
 * return >=0string lenth other:wrong
 * */
extern int SocketSendString(char* data, char* sName);

/*receive string
 * data: retrun string data
 * sName: socket name
 *
 * return >=0string lenth other:wrong
 * */
extern int SocketRecvString(char* data, char* sName);

/*sent double
 * data: double data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int SocketSendDouble(double data, char* sName);

/*receive double
 * data: retrun double data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int SocketRecvDouble(double* data, char* sName);

/*sent int
 * data: int data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int SocketSendInt(int data, char* sName);

/*receive int
 * data: retrun int data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int SocketRecvInt(int* data, char* sName);

/*sent byte array
 * data: byte array data
 * n: data number
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int SocketSendByteArray(int* data,int n,char* sName);

/*receive byte array
 * data: return byte array data
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int SocketRecvByteArray(int* data, char* sName);

/*sent double array
 * data: doube array data
 * n: data number
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int SocketSendDoubleArray(double* data, int n,char* sName);

/*receive double array
 * data: return double array data
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int SocketRecvDoubleArray(double* data, char* sName);

/*sent int array
 * data: int array data
 * n: data number
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int SocketSendIntArray(int* data, int n, char* sName);

/*receive int array
 * data: return int array data
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int SocketRecvIntArray(int* data, char* sName);

/*UDP create socket server
 * ip: ip
 * port: port
 * sName: server name
 *
 * return 0:right other:wrong
 * */
extern int UDPServerCreate(char* ip, int port, char* sName);

/*UDP create socket client
 * ip: ip
 * port: port
 * sName: client name
 *
 * return 0:right other:wrong
 * */
extern int UDPClientCreate(char* ip, int port, char* sName);

/*UDP close socket server or client
 * sName: server or client name
 *
 * return 0:right other:wrong
 * */
extern int UDPClose(char* sName);

/*UDP sent byte
 * data: byte data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int UDPSendByte(int data, char* sName);

/*UDP receive byte
 * data: return byte data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int UDPRecvByte(int* data, char* sName);

/*UDP sent string
 * data: string data
 * sName: socket name
 *
 * return >=0string lenth other:wrong
 * */
extern int UDPSendString(char* data, char* sName);

/*UDP receive string
 * data: retrun string data
 * sName: socket name
 *
 * return >=0string lenth other:wrong
 * */
extern int UDPRecvString(char* data, char* sName);

/*UDP sent double
 * data: double data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int UDPSendDouble(double data, char* sName);

/*UDP receive double
 * data: retrun double data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int UDPRecvDouble(double* data, char* sName);

/*UDP sent int
 * data: int data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int UDPSendInt(int data, char* sName);

/*UDP receive int
 * data: retrun int data
 * sName: socket name
 *
 * return 1:right other:wrong
 * */
extern int UDPRecvInt(int* data, char* sName);

/*UDP sent byte array
 * data: byte array data
 * n: data number
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int UDPSendByteArray(int* data,int n,char* sName);

/*UDP receive byte array
 * data: return byte array data
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int UDPRecvByteArray(int* data, char* sName);

/*UDP sent double array
 * data: doube array data
 * n: data number
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int UDPSendDoubleArray(double* data, int n,char* sName);

/*UDP receive double array
 * data: return double array data
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int UDPRecvDoubleArray(double* data, char* sName);

/*UDP sent int array
 * data: int array data
 * n: data number
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int UDPSendIntArray(int* data, int n, char* sName);

/*UDP receive int array
 * data: return int array data
 * sName: socket name
 *
 * return >0: number of the data; other: wrong
 * */
extern int UDPRecvIntArray(int* data, char* sName);

//----------------------------------------------------------------------------------------thread interface--------------------------------------------------------------------------
/*create thread
 * fun: thread execute function
 * arg: execute function
 * name: thread name
 * detached_flag: thread attribute,0:PTHREAD_CREATE_JOINABLE  other:PTHREAD_CREATE_DETACHED
 *
 * return 0:right; other: wrong
 * */
extern int ThreadCreat(void* (*fun)(void*), void* arg, char* name, int detached_flag);

/*thread data free
 * name: thread name
 * */
extern int ThreadDataFree(char* name);

/*thread join (It works when thread attribute is PTHREAD_CREATE_JOINABLE)
 * name thread name
 * return 0:right; other: wrong
 * */
extern int ThreadWait(char* name);

/////////////////////////////////////////////////////////////////////////////////////////

/*close grip
 *pos: _ROBOTIQ:夹具夹紧程度，从0.0~1.0之间取值，0.0完全伸展开，1.0处于夹紧状态；
 *
 * return 0:right other:wrong
 * */
extern int grip_position(double pos);


#endif /* ROBOTLIB_H_ */

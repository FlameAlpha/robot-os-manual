/*
 * RobotEtherCAT.h
 *
 *  Created on: 2018-5-2
 *      Author: hanbing
 */

#ifndef ROBOTETHERCAT_H_
#define ROBOTETHERCAT_H_

extern char* EC_deviceName[2];

	/*creat EtherCAT device
	 * ecName: device name
	 *
	 * return 0:rigtht; other: wrong
	 * */
extern int createEC_device(char* ecName);

	/*creat EtherCAT device
	 * ecName: device name
	 * _wrsize_name: data size name
	 * _variable_name: variable name
	 * _fd_ecat_in_name:in name
	 * _fd_ecat_out_name: out name
	 * inipath: configure file path
	 * ininame: configure file name
	 *
	 * return 0:rigtht; other: wrong
	 * */
extern int createEC_device2(char* ecName, char* _wrsize_name,char* _variable_name,char* _fd_ecat_in_name,char* _fd_ecat_out_name, char* inipath, char* ininame);

	/*destroy EtherCAT device
	 * ecName: device name
	 *
	 * return 0:rigtht; other: wrong
	 * */
extern int destroyEC_device(char* ecName);

	/*get EtherCAT device number
	 *
	 * return device number, <0:wrong
	 * */
extern int getEC_deviceNum();

	/*get EtherCAT device name
	 * index: device index
	 * name: return device name
	 *
	 * return name  pointer;NULL: wrong
	 * */
extern char* getEC_deviceName(int index,char* name);

	/*get digital IO subset number
	 * ecName: EtherCAT device name
	 *
	 * return subset number, <0: wrong
	 * */
extern int hasNumber_dioEC_deviceHandle_c(char* ecName);

	/*get analog IO subset number
	 * ecName: EtherCAT device name
	 *
	 * return subset number, <0: wrong
	 * */
extern int hasNumber_aioEC_deviceHandle_c(char* ecName);

	/*get addition axissubset number
	 * ecName: EtherCAT device name
	 *
	 * return subset number, <0: wrong
	 * */
extern int hasNumber_additionaxisEC_deviceHandle_c(char* ecName);

	/*get robotsubset number
	 * ecName: EtherCAT device name
	 *
	 * return subset number, <0: wrong
	 * */
extern int hasNumber_robotEC_deviceHandle_c(char* ecName);

	/*get digital IO subset name
	 * ecName: EtherCAT device name
	 *
	 * return subset name, NULL: wrong
	 * */
extern char* get_name_dioEC_deviceHandle_c(char* ecName);

	/*get analog IO subset name
	 * ecName: EtherCAT device name
	 *
	 * return subset name, NULL: wrong
	 * */
extern char* get_name_aioEC_deviceHandle_c(char* ecName);

	/*get addition axis subset name
	 * ecName: EtherCAT device name
	 *_index:addition axis subset index
	 *
	 * return subset name, NULL: wrong
	 * */
extern char* get_name_additionaxisEC_deviceHandle_c(char* ecName, int _index);

	/*get robot subset name
	 * ecName: EtherCAT device name
	 *_index:robot subset index
	 *
	 * return subset name, NULL: wrong
	 * */
extern char* get_name_robotEC_deviceHandle_c(char* ecName, int _index);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
 * usage:
 * 	createEC_device("******");//create a ethercat device use name "******", this ethercat device is global, can be use  anywhere.
 *
 *    robot_getposition_c ("****** /robot0", pos);//It can be used like this, other similar
       or
       robot_getposition_c(get_name_robotEC_deviceHandle_c("******", 0), pos);
 * */

    //====================================axis====================================
	/*power for one axis
	 * ecHName: subset name
	 * axis_ID: axis index
	 *
	 * return: 0:right; other:wrong
	 * */
extern int axis_power_c(char* ecHName,int axis_ID);

	/*poweroff for one axis
	 * ecHName: subset name
	 * axis_ID: axis ID
	 *
	 * return: 0:right; other:wrong
	 * */
extern  int axis_poweroff_c(char* ecHName,int axis_ID);

	/*set mode for one axis
	 * ecHName: subset name
	 * mode: actuator mode
	 * axis_ID: axis ID
	 *
	 * return: 0:right; other:wrong
	 * */
extern int axis_setmode_c(char* ecHName,signed char mode,int axis_ID);

	/*set control word for one axis
	 * ecHName: subset name
	 * control: actuator control word
	 * axis_ID: axis ID
	 *
	 * return: 0:right; other:wrong
	 * */
extern int axis_setcontrol_c(char* ecHName,unsigned short control,int axis_ID);

	/*get status word for one axis
	 * ecHName: subset name
	 * axis_ID: axis ID
	 *
	 * return: status word; <0:wrong
	 * */
extern unsigned short axis_getstatus_c(char* ecHName,int axis_ID);

    /*get position for one axis
	 * ecHName: subset name
	 * axis_ID: axis ID
	 *
	 * return position
     * */
extern int axis_getposition_c(char* ecHName,int axis_ID);

    /*get target position for one axis
	 * ecHName: subset name
	 * axis_ID: axis ID
	 *
	 * return position
     * */
extern int axis_getposition_target_c(char* ecHName,int axis_ID);

    /*get velocity for one axis
	 * ecHName: subset name
	 * axis_ID: axis ID
	 *
	 * return velocity
     * */
extern int axis_getvelocity_c(char* ecHName,int axis_ID);

    /*get torque for one axis
	 * ecHName: subset name
	 * axis_ID: axis ID
	 *
	 * return torque
     * */
extern short axis_gettorque_c(char* ecHName,int axis_ID);

    /*get current for one axis
	 * ecHName: subset name
	 * axis_ID: axis ID
	 *
	 * return current
     * */
extern short axis_getcurrent_c(char* ecHName,int axis_ID);

    /*set position for one axis
	 * ecHName: subset name
	 * pos: target position
	 * axis_ID: axis ID
	 *
	 * return 0:wrong; other: wrong
     * */
extern int axis_setposition_c(char* ecHName,int pos,int axis_ID);

    /*set velocity for one axis
	 * ecHName: subset name
	 * vel: target velocity
	 * axis_ID: axis ID
	 *
	 * return 0:wrong; other: wrong
     * */
extern int axis_setvelocity_c(char* ecHName,int vel,int axis_ID);

    /*set torque for one axis
	 * ecHName: subset name
	 * tor: target torque
	 * axis_ID: axis ID
	 *
	 * return 0:wrong; other: wrong
     * */
extern int axis_settorque_c(char* ecHName,short tor,int axis_ID);

    /*set digital IO
	 * ecHName: subset name
	 * id_index: digital IO index
	 * flag: IO value,0 or 1
	 *
	 * return 0:wrong; other: wrong
     * */
extern int setdo_c(char* ecHName, int id_index,int flag);

    /*set analog IO
	 * ecHName: subset name
	 * id_index: digital IO index(0,1,2....)
	 * ao: analog value
	 *
	 * return 0:wrong; other: wrong
     * */
extern int setao_c(char* ecHName, int id_index, short ao);

    /*get analog IO
	 * ecHName: subset name
	 * id_index: digital IO index(0,1,2....)
	 * ai:  return analog value
	 *
	 * return analog value
     * */
extern int getai_c(char* ecHName,int id_index, short* ai);


    //====================================robot====================================
    /*get subset number
     * ecName: EhterCAT device name
     *
     * return: subset number;
     * */
extern int get_EC_deviceHandeNum_c(char* ecName);

    /*get EtherCAT communication cycle (ns)
     * ecName: EhterCAT device name
     *
     * return EtherCAT communication cycle(ns)
     * */
extern int get_BusyTs_c(char* ecName);

/*get EtherCAT communication cycle (s)
 * ecName: EhterCAT device name
 *
 * return EtherCAT communication cycle(s)
 * */
extern double get_BusyTs_s_c(char* ecName);

    /*printf EtherCAT device data
     * ecName: EtherCAT device name
     * */
extern void EC_device_printf_c(char* ecName);


//-----------------------------------------------------------------------
    /*get robot or addition axis dof
     * ecHName: robot subset name
     *
     * return robot dof
     * */
extern int getRobotDOF_c(char* ecHName);

    /*power for robot or addition axis
     * ecHName: robot subset name
     *
     * return 0: right; other: wrong
     * */
extern int robot_power_c(char* ecHName);

    /*poweroff for robot or addition axis
     * ecHName: robot subset name
     *
     * return 0: right; other: wrong
     * */
extern int robot_poweroff_c(char* ecHName);

    /*set mode for robot or addition axis
     * ecHName: robot subset name
     * mode: actuator mode
     *
     * return 0: right; other: wrong
     * */
extern void robot_setmode_c(char* ecHName,signed char* mode);

    /*get positon for robot or addition axis
     * ecHName: robot subset name
     * pos: return poition
     * */
extern  void robot_getposition_c(char* ecHName,int* pos);

    /*get target positon for robot or addition axis
     * ecHName: robot subset name
     * pos: return target poition
     * */
extern void robot_getposition_target_c(char* ecHName,int* pos);

    /*get velocity for robot or addition axis
     * ecHName: robot subset name
     * vel: return velocity
     * */
extern void robot_getvelocity_c(char* ecHName,int* vel);

    /*get torque for robot or addition axis
     * ecHName: robot subset name
     * tor: return torque
     * */
extern void robot_gettorque_c(char* ecHName,short* tor);

    /*get current for robot or addition axis
     * ecHName: robot subset name
     * cur: return current
     * */
extern void robot_getcurrent_c(char* ecHName,short* cur);

/*get current for robot or addition axis
 * ecHName: robot subset name
 * cur: return current
 * */
extern void robot_getcurrent_c(char* ecHName,short* cur);

    /*set positon for robot or addition axis
     * ecHName: robot subset name
     * pos: target poition
     * */
extern void robot_setposition_c(char* ecHName,int* pos);

    /*set velocity for robot or addition axis
     * ecHName: robot subset name
     * vel target velocity
     * */
extern void robot_setvelocity_c(char* ecHName,int* vel);

    /*set torque for robot or addition axis
     * ecHName: robot subset name
     * tor: target torque
     * */
extern void robot_settorque_c(char* ecHName,short* tor);


#endif /* ROBOTETHERCAT_H_ */

/*
 * kinematicInterface.h
 *
 *  Created on: 2019-5-7
 *      Author: hanbing
 */

#ifndef KINEMATICINTERFACE_H_
#define KINEMATICINTERFACE_H_

typedef struct{
	int robhold;
	double toolframe[6];
}TOOL;

typedef struct{
	int robhold;
	int ufprog;
	int ufmec;
	double workframe[6];
	double userframe[6];
}WOBJ;


typedef struct{
	double		R[3][3];
	double		X[3];
	double		joint[10];
	double		kps[3];
	int       		dof;
	double      redundancy;

	TOOL tool;
	WOBJ wobj;
}R7_KINE;

extern void init_R7_KINE(R7_KINE* rkine);

/*forward kinematics
 * serialLinkName: model name
 * r7kine: result
 *
 * return 0:right; other: wrong
 * */
extern int Kine_Forward(char* serialLinkName, R7_KINE* r7kine);

/*inverse kinematics
 * serialLinkName: model name
 * r7kine: result
 *
 * return 0:right; other: wrong
 * */
extern int Kine_Inverse(char* serialLinkName, R7_KINE* r7kine);

#endif /* KINEMATICINTERFACE_H_ */

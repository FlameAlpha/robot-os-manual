#!/bin/sh
cp ./RobotControlLib/Debug/libRobotControlLib.so ./RobotLib/lib/*.so /usr/lib



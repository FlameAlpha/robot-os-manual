#!/bin/sh
scp ./RobotControlLib/Debug/libRobotControlLib.so ./RobotLib/lib/*.so* root@192.168.0.99:/usr/lib
scp ./RobotMain/Debug/RobotMain root@192.168.0.99:/robot


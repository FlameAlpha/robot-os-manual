/*
 * RobotControl.h
 *
 *  Created on: 2017年9月21日
 *      Author: hanbing
 */

#ifndef INCLUDE_ROBOTCONTROL_H_
#define INCLUDE_ROBOTCONTROL_H_

//控值主函数
int MainControl();

#endif /* INCLUDE_ROBOTCONTROL_H_ */

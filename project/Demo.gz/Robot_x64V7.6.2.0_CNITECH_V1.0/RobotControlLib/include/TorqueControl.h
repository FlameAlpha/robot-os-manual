
#ifndef TORQUECONTROL_H_
#define TORQUECONTROL_H_

void torqueControl();


#endif /* TORQUECONTROL_H_ */

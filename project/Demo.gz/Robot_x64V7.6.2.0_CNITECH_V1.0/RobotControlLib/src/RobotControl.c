/*
 * RobotControl.c
 *
 *  Created on: 2017年9月21日
 *      Author: hanbing
 */
#include"RobotControl.h"
#include <pthread.h>
#include "key.h"
#include "TorqueControl.h"
#include "saveData.h"
#include "RobotLib.h"

static pthread_t PthControl;
static pthread_t PthKey;
static pthread_t PthDataSave;
static pthread_t task_timer;
static pthread_attr_t attr;

void* PthControlF(void*  arg)
{
	torqueControl();
	return NULL;
}

int initControl()
{
	//-----------------------自定义初始化操作-----------------------
	//设置进程优先级
	int err=initPriority();
	if (0!=err)
	{
		printf("initPriority failure!\n");
		return err;
	}

	//初始化共享数据
	err=initSHARE_DATA();
	if (0!=err)
	{
		printf("initSHARE_DATA failure!\n");
		return err;
	}

	//EtherCAT initialize
	err=createEC_device2(EC_deviceName[0],"/sizeset","/xml_analise","/ecat_in","/ecat_out","/hanbing/", "busConfig.ini");
	EC_device_printf_c(EC_deviceName[0]);//仅仅用于打印总线信息，可以注释
	if (0!=err)
	{
		printf("InitEC_device failure\n");
		return err;
	}

	//定时器初始化
	initTimer(0);
	pthread_attr_init( &attr );
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
	err=pthread_create(&task_timer,&attr, ecTimer, NULL ); //robot control task timer
	if(err != 0)
	{
		printf(" timer pthread create error\n");
		return err;
	}

	return 0;
}

int MainControl()
{
	int err=0;

	//初始化
//	err=initControl();
//	if (0!=err)
//	{
//		printf("initControl failure\n");
//		return err;
//	}
	pthread_attr_init( &attr );
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	//键盘响应
	err = pthread_create(&PthKey, &attr, thread_key, NULL);
	if (err != 0)
	{
		printf("PthKey error\n");
		return err;
	}

    //控制线程
	err = pthread_create(&PthControl, &attr, PthControlF, NULL);
	if (err != 0)
	{
		printf("PthTorqueControl error\n");
		return err;
	}

	err = pthread_create(&PthDataSave, &attr, saveDataToFile, NULL);
	if (err != 0)
	{
		printf("saveDataToFile error\n");
		return err;
	}
	//------------------------------自定义------------------------------------------




	return 0;
}






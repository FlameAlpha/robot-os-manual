

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "TorqueControl.h"
#include <math.h>
#include "torque_control_demo.h"
#include "key.h"
#include "RobotLib.h"


extern KEY_DATA msg_key;

double dt=0;
char* robot_name=NULL;

void torqueControl()
{
	robot_name=get_name_robotEC_deviceHandle_c(getEC_deviceName(0,NULL),0);//获取操作设备名称
	int _mode=8;
	signed char act_mode[10]={_mode,_mode,_mode,_mode,_mode,_mode,_mode,_mode,_mode,_mode};
	robot_setmode_c(robot_name,act_mode);//设置初始化模式，运行过程中切换模式，可以在键盘中键入如：mode 10 切换为力距模式

//	int axis_timmer=get_BusyTs_c(getEC_deviceName(0,NULL));//获取总线周期，ns
//	dt=0.000000001*axis_timmer;//控制周期（s）
	dt=get_BusyTs_s_c(getEC_deviceName(0,NULL));

	while (1)
	{
		torqueTimerE(0);//定时器，定时时间与总线周期一致

		if ((1==msg_key.power)&&(1==msg_key.start))
		{
			//interface_demo();//一个总线周期内完成。下一个总线周期会再次进入。
		}

		if (1==msg_key.file) //record data
		{
			data_logging();
		}

		if (1==msg_key.position_on)
		{
			interface_position_demo();
		}
		if (1==msg_key.position_off)
		{
			interface_position_demo_close();
			msg_key.position_off=0;
		}
		if (1==msg_key.velocity_on)
		{
			interface_velocity_demo();
		}
		if (1==msg_key.velocity_off)
		{
			interface_velocity_demo_close();
			msg_key.velocity_off=0;
		}
		if (1==msg_key.torque_on)
		{
			interface_torque_demo();
		}
		if (1==msg_key.torque_off)
		{
			interface_torque_demo_close();
			msg_key.torque_off=0;
		}

	}
}





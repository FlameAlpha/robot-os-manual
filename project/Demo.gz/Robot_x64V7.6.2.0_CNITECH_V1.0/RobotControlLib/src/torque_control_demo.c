/*
 * torque_control_demo.c
 *
 *  Created on: 2018-4-1
 *      Author: hanbing
 */
#include "torque_control_demo.h"
#define pi 3.1415926
static int position_0[10];
extern double dt;
extern double motion_A[10];
extern double motion_f[10];
extern double motion_t;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//读运行数据到缓存区（配合key.c 的w,nw 命令使用。）
void data_logging()
{
	int i=0;
	char* robot_name=get_name_robotEC_deviceHandle_c(getEC_deviceName(0,NULL),0);
	int _dof=getRobotDOF_c(robot_name);
	double ac_value[100];

	int position[10];
	short torque[10];
	int velocity[10];
	int target_position[10];
	int motor_position[10];
	int motor_velocity[10];
	short motor_torque[10];

	double _angle[10];
	double _angle_t[10];
	double _angular[10];
	double _torque1[10];
    robot_getposition_c(robot_name,position);
    robot_getvelocity_c(robot_name,velocity);
    robot_gettorque_c(robot_name,torque);
    robot_getposition_target_c(robot_name,target_position);

    robot_getposition_angle(robot_name, _angle);
    robot_getposition_angle_target(robot_name, _angle_t);
    robot_getvelocity_angular(robot_name, _angular);
    robot_gettorque_torque(robot_name, _torque1);


	for (i=0;i<_dof;i++)
	{
		ac_value[0*_dof+i]=(double)position[i];//1
		ac_value[1*_dof+i]=(double)velocity[i];//8
		ac_value[2*_dof+i]=(double)torque[i];//15
		ac_value[3*_dof+i]=(double)target_position[i];//22

		ac_value[4*_dof+i]=(double)motor_position[i];//29
		ac_value[5*_dof+i]=(double)motor_velocity[i];//36
		ac_value[6*_dof+i]=(double)motor_torque[i];//43

		ac_value[7*_dof+i]=_angle[i];//50
		ac_value[8*_dof+i]=_angle_t[i];//57
		ac_value[9*_dof+i]=_angular[i];//64
		ac_value[10*_dof+i]=_torque1[i];//71
	}
	saveData(ac_value, _dof*11);
}

static int __init_interface_position_demo=0;
//EtherCAT接口使用demo
void interface_position_demo()
{
	init_interface_position_demo();
	char* robot_name=get_name_robotEC_deviceHandle_c(getEC_deviceName(0,NULL),0);
	int position[10];
	int i=0;
	int _dof=getRobotDOF_c(robot_name);
	for (i=0;i<_dof;i++)
	{
		position[i]=position_0[i]+(int)(motion_A[i]*cos(2*pi*motion_f[i]*motion_t))-motion_A[i];//设置期望编码器位置
	}

	motion_t=motion_t+dt;
	robot_setposition_c(robot_name,position);
}

void init_interface_position_demo()
{
	if (0==__init_interface_position_demo)
	{
//		char* robot_name=get_name_robotEC_deviceHandle_c(getEC_deviceName(0,NULL),0);
//		robot_get_motor_position_c(robot_name,position_0);
		__init_interface_position_demo=1;
		motion_t=0;
	}
}

void interface_position_demo_close()
{
	__init_interface_position_demo=0;
}

static int __init_interface_torque_demo=0;
//EtherCAT接口使用demo
void interface_torque_demo()
{
	init_interface_torque_demo();
	char* robot_name=get_name_robotEC_deviceHandle_c(getEC_deviceName(0,NULL),0);
	short tor[10];
	int i=0;
	int _dof=getRobotDOF_c(robot_name);
	for (i=0;i<_dof;i++)
	{
		tor[i]=(short)(motion_A[i]*sin(2*pi*motion_f[i]*motion_t));//设置期望编码器位置
		//printf("%d,",tor[i]);
	}
	//printf("\n");
	motion_t=motion_t+dt;
	robot_settorque_c(robot_name,tor);
}

void init_interface_torque_demo()
{
	if (0==__init_interface_torque_demo)
	{
		__init_interface_torque_demo=1;
		motion_t=0;
	}
}

void interface_torque_demo_close()
{
	char* robot_name=get_name_robotEC_deviceHandle_c(getEC_deviceName(0,NULL),0);
	short tor[10]={0,0,0,0,0,0,0,0,0,0};
	robot_settorque_c(robot_name,tor);
	__init_interface_torque_demo=0;
}

static int __init_interface_velocity_demo=0;
void interface_velocity_demo()
{
	init_interface_velocity_demo();
	char* robot_name=get_name_robotEC_deviceHandle_c(getEC_deviceName(0,NULL),0);
	int vel[10];
	int i=0;
	int _dof=getRobotDOF_c(robot_name);
	for (i=0;i<_dof;i++)
	{
		vel[i]=(int)(motion_A[i]*sin(2*pi*motion_f[i]*motion_t));//设置期望编码器位置
	}

	motion_t=motion_t+dt;
	robot_setvelocity_c(robot_name, vel);
}

void init_interface_velocity_demo()
{
	if (0==__init_interface_velocity_demo)
	{
		__init_interface_velocity_demo=1;
		motion_t=0;
	}
}

void interface_velocity_demo_close()
{
	char* robot_name=get_name_robotEC_deviceHandle_c(getEC_deviceName(0,NULL),0);
	int vel[10]={0,0,0,0,0,0,0,0,0,0};
	robot_setvelocity_c(robot_name, vel);
	__init_interface_velocity_demo=0;
}

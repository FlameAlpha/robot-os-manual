/*
 * functionTest.h
 *
 *  Created on: 2018-3-15
 *      Author: hanbing
 */

#ifndef FUNCTIONTEST_H_
#define FUNCTIONTEST_H_

void fucntionTest(int flag);

#endif /* FUNCTIONTEST_H_ */

/**
 * @file
 * @keyboard click signs
 * @author yf
 * @date 2016-10-26
 * @version 0.2
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "key.h"
#include <termios.h>
#include "saveData.h"
#include "RobotLib.h"
#include <math.h>
#define pi  3.1415926535898
//#define THREAD_KEY   //define THREAD_KEY, use pthread thread_key(), but function can't backgrounder. if not define THREAD_KEY, function can be run in background.

KEY_DATA msg_key;

extern char* EC_deviceName[2];
double motion_A[10]={1,1,1,1,1,1,1,1,1,1};
double motion_f[10]={0.2,0.2,0.2,0.2,0.2,0.2,0.2,0.2,0.2,0.2};
double motion_t=0;

extern int Rdebug(const char *__restrict __format, ...);

void init_KEY_DATA(KEY_DATA* kd)
{
	kd->power=0;
	kd->start=0;
	kd->file=0;
	kd->dyn_control_test=0;
	kd->dyn_identify_test=0;
	kd->init_start=0;
	kd->invert_pendulum_init=0;
	kd->invert_pendulum_start=0;

	kd->direct_teach_on=0;
	kd->direct_teach_off=0;
}


void *thread_key(void *arg)
{

	memset(&msg_key,0,sizeof(msg_key));

#ifdef THREAD_KEY
	char c[40];
	while(1)
	{
		memset(c,'\0',sizeof(c));
		if (NULL==fgets(c,sizeof(c),stdin))  //程序不能后台运行
		{
			continue;
		}
		int c_len=strlen(c);
		c[c_len-1]='\0';//去掉'\n'
		RobotControlOrder(c, 0);
	}
#endif
	return NULL;
}

void RobotControlOrder(char* c, int _robot_index)
{
	if(strcmp(c,"init")==0)
	{
		RobCtrl_init();
	}
	if(strcmp(c,"power")==0)
	{
		RobCtrl_power(_robot_index);
	}
	if(strcmp(c,"poweroff")==0)
	{
		RobCtrl_poweroff(_robot_index);
	}
	if(strcmp(c,"start")==0)
	{
		RobCtrl_start();
	}
	if(strcmp(c,"end")==0)
	{
		RobCtrl_end();
	}
	if(strcmp(c,"w")==0)
	{
		RobCtrl_w();
	}
	if(strcmp(c,"nw")==0)
	{
		RobCtrl_nw();
	}
    //mode 1 8
	if (strncmp(c,"mode", 4)==0)
	{
		RobCtrl_key_setMode(c,_robot_index);
	}
    //axis_power 1 1
	if (strncmp(c,"axis_power", 10)==0)
	{
		RobCtrl_key_axis_power(c, _robot_index);
	}

    //A 0 100.0
	if (strncmp(c,"A", 1)==0)
	{
		RobCtrl_key_setAf(c,0);
	}
	//f 0 100.0
	if (strncmp(c,"f", 1)==0)
	{
		RobCtrl_key_setAf(c,1);
	}
	if(strcmp(c,"showAf")==0)
	{
		RobCtrl_key_setAf(c,2);
	}

	if(strcmp(c,"test_on")==0)
	{
		RobCtrl_test_on();
	}

	if(strcmp(c,"test_off")==0)
	{
		RobCtrl_test_off();
	}

	if(strcmp(c,"position_on")==0)
	{
		RobCtrl_position_on();
	}

	if(strcmp(c,"position_off")==0)
	{
		RobCtrl_position_off();
	}
	if(strcmp(c,"velocity_on")==0)
	{
		RobCtrl_velocity_on();
	}

	if(strcmp(c,"velocity_off")==0)
	{
		RobCtrl_velocity_off();
	}
	if(strcmp(c,"torque_on")==0)
	{
		RobCtrl_torque_on();
	}

	if(strcmp(c,"torque_off")==0)
	{
		RobCtrl_torque_off();
	}
}

static void _getParameter(char* c, int* mode, int *i)
{
   char index[50];
   char* p=c;
   char* q=index;
   memset(index,'\0',sizeof(index));
   while (' '!=*p)
   {
	   p++;
   }
   while (' '==*p)
   {
	   p++;
   }
   while(' '!=*p)
   {
	   *q=*p;
	   p++;
	   q++;
   }
   *q='\0';
   *i=atoi(index);
	while(' '==*p)
	{
		p++;
	}
    memset(index,'\0',sizeof(index));
    q=index;
    while('\0'!=*p)
	   {
		   *q=*p;
		   p++;
		   q++;
	   }
    *q='\0';
    *mode=atoi(index);
}


static void _getParameter_double(char* c, double* value, int *i)
{
   char index[50];
   char* p=c;
   char* q=index;
   memset(index,'\0',sizeof(index));
   while (' '!=*p)
   {
	   p++;
   }
   while (' '==*p)
   {
	   p++;
   }
   while(' '!=*p)
   {
	   *q=*p;
	   p++;
	   q++;
   }
   *q='\0';
   *i=atoi(index);
	while(' '==*p)
	{
		p++;
	}
    memset(index,'\0',sizeof(index));
    q=index;
    while('\0'!=*p)
	   {
		   *q=*p;
		   p++;
		   q++;
	   }
    *q='\0';
    *value=atof(index);
}

/*set mode

 * */
void RobCtrl_key_setMode(char* c, int _robot_index)
{
	char* robot_name=get_name_robotEC_deviceHandle_c(EC_deviceName[0],_robot_index);
	int _dof=getRobotDOF_c(robot_name);
	int axis_ID=0;
	int mode=8;
	 _getParameter(c, &mode, &axis_ID);
	if (axis_ID<=_dof&&axis_ID>=1&&mode>=8&&mode<=10)
	{
		axis_setmode_c(robot_name,mode,axis_ID);
		Rdebug("set axis: %d,mode:%d\n",axis_ID,mode);
	}else if (axis_ID==100&&mode>=8&&mode<=10)
	{
		signed char _mode[10]={mode,mode,mode,mode,mode,mode,mode,mode,mode,mode};
		robot_setmode_c(robot_name,_mode);
		Rdebug("set all axismode:%d\n",mode);
	}
	else
	{
		Rdebug("set mode failure!\n");
	}
}


/*set Af

 * */
void RobCtrl_key_setAf(char* c,int flag)
{
	int i=0;
	int axis_ID=0;
	double value=0;
	if (0==flag||1==flag)
	{
		_getParameter_double(c, &value, &axis_ID);
	}


	if (0==flag)
	{
		motion_A[axis_ID]=value;
		Rdebug("A[%d]=%f\n",axis_ID,value);
	}
	else if (1==flag)
	{
		motion_f[axis_ID]=value;
		Rdebug("f[%d]=%f\n",axis_ID,value);
	}
	else
	{
		for (i=0;i<10;i++)
		{
			Rdebug("A[%d]=%f, f[%d]=%f\n",i,motion_A[i],i,motion_f[i]);
		}
	}
}

void RobCtrl_key_axis_power(char* c, int _robot_index)
{
	char* robot_name=get_name_robotEC_deviceHandle_c(EC_deviceName[0],_robot_index);
	int _dof=getRobotDOF_c(robot_name);
	int axis_ID=0;
	int on=8;
	 _getParameter(c, &on, &axis_ID);
	if (axis_ID<=_dof&&axis_ID>=1&&(on==0||on==1))
	{
		if (1==on)
		{
			axis_power_c(robot_name, axis_ID);
			Rdebug("axis %d power\n",axis_ID);
		}
		else
		{
			axis_poweroff_c(robot_name, axis_ID);
			Rdebug("axis %d poweroff\n",axis_ID);
		}
	}
	else
	{
		Rdebug("power or poweroff failure!\n");
	}

}


double cycle_data_generate(double A,double f,double t)
{
	int _sign=1;
	double _A=A/2.0;
	double _f=f*2.0;
	if (_f<0)
	{
		return 0;
	}
	int _tmp=(int)(t*_f);
	if (0==_tmp%2)
	{
		_sign=1;
	}
	else
	{
		_sign=-1;
	}
//	double ret=_sign*(_A*cos(2*pi*_f*t)-_A);
//	if (_tmp==0)
//	Rdebug("%f\n",ret);
//	return ret;
	return _sign*(_A*cos(2*pi*_f*t)-_A);
}

double constant_data_generate(double A,double f,double t)
{
	double _A=A/2.0;
	double _f=f;
	double ret=0;
	if (_f<0)
	{
		return 0;
	}
	if (t<=0)
	{
		ret=0;
	}
	else if (t>=(0.5/_f))
	{
		ret=A;
	}
	else
	{
		ret=(_A*cos(2*pi*_f*t)-_A);
	}

	return ret;
}


void RobCtrl_nw()
{
	msg_key.file = 0;
	usleep(1000);
	closeFile();
	Rdebug("over write file\n");
}

void RobCtrl_w()
{
	if (0==openFile())
	{
		usleep(1000);
		msg_key.file = 1;
		Rdebug("start write file\n");
	}
	else
	{
		msg_key.file = 0;
		Rdebug("can't write file\n");
	}
}

void RobCtrl_end()
{
	msg_key.start = 0;
	Rdebug("system end\n");
}

void RobCtrl_start()
{
	msg_key.start = 1;
	Rdebug("system start\n");
}

void RobCtrl_poweroff(int _robot_index)
{
	char* robot_name=get_name_robotEC_deviceHandle_c(EC_deviceName[0],_robot_index);
	msg_key.power = 0;
	usleep(1000);
	double torValue[10]={0,0,0,0,0,0,0,0,0,0};
	robot_settorque_torque(robot_name, torValue);
	usleep(1000);
	robot_poweroff_c(robot_name);
	Rdebug("system poweroff\n");
}

void RobCtrl_power(int _robot_index)
{
	char* robot_name=get_name_robotEC_deviceHandle_c(EC_deviceName[0],_robot_index);
	signed char _mode[10]={8,8,8,8,8,8,8,8,8,8};
	robot_setmode_c(robot_name,_mode);
    usleep(10);
	robot_power_c(robot_name);
	usleep(1000);
	msg_key.power = 1;
	Rdebug("system power\n");
}

void RobCtrl_init()
{
	msg_key.init_start = 1;
	Rdebug("init start\n");
}

void RobCtrl_test_on()
{
		msg_key.test_on= 1;
		Rdebug("test_on\n");

}

void RobCtrl_test_off()
{
	msg_key.test_off= 1;
	msg_key.test_on= 0;
	Rdebug("test_off\n");
}

void RobCtrl_position_on()
{
		msg_key.position_on= 1;
		Rdebug("position_on\n");

}

void RobCtrl_position_off()
{
	msg_key.position_off= 1;
	msg_key.position_on= 0;
	Rdebug("position_off\n");
}

void RobCtrl_velocity_on()
{
		msg_key.velocity_on= 1;
		Rdebug("velocity_on\n");

}

void RobCtrl_velocity_off()
{
	msg_key.velocity_off= 1;
	msg_key.velocity_on= 0;
	Rdebug("velocity_off\n");
}

void RobCtrl_torque_on()
{
		msg_key.torque_on= 1;
		Rdebug("torque_on\n");

}

void RobCtrl_torque_off()
{
	msg_key.torque_off= 1;
	msg_key.torque_on= 0;
	Rdebug("torque_off\n");
}

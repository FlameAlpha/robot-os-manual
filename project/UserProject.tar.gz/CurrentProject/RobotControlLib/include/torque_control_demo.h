/*
 * torque_control_demo.h
 *
 *  Created on: 2018-4-1
 *      Author: hanbing
 */

#ifndef TORQUE_CONTROL_DEMO_H_
#define TORQUE_CONTROL_DEMO_H_
#include "RobotLib.h"
#include "saveData.h"
#include <math.h>

//读运行数据到缓存区（配合key.c 的w,nw 命令使用。）
void data_logging();

//EtherCAT接口使用demo
void interface_position_demo();

void init_interface_position_demo();

void interface_position_demo_close();
//EtherCAT接口使用demo
void interface_torque_demo();

void init_interface_torque_demo();

void interface_torque_demo_close();
void interface_velocity_demo();

void init_interface_velocity_demo();

void interface_velocity_demo_close();

#endif /* TORQUE_CONTROL_DEMO_H_ */

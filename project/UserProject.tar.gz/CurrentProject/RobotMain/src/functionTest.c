/*
 * functionTest.c
 *
 *  Created on: 2018-3-15
 *      Author: hanbing
 */

#include "functionTest.h"

void fucntionTest(int flag)
{
	if (0==flag)
	{
		return;
	}

}

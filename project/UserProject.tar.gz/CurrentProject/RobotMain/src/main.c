/*
 * main.c
 *
 *  Created on: 2017-5-2
 *      Author: HanBing
 */
#include <stdlib.h>
#include <stdio.h>

#include "functionTest.h"
#include"RobotControl.h"
#include "RobotLib.h"

int main(int argc, char *argv[])
{
	//------------------------initialize----------------------------------
	int err=0;
	command_arg arg;
	err=commandLineParser(argc, argv,&arg);
	if (0!=err)
	{
		return -1;
	}
	err=system_initialize(&arg);
//	err=rob_initialize(arg.mode, arg.path);
	if (0!=err)
	{
		return err;
	}
	//------------------------custom control----------------------------------
	err=MainControl();
	if (0!=err)
	{
		return err;
	}
	//------------------------test----------------------------------
	fucntionTest(1);




	//------------------------wait----------------------------------
	while(1)
	{
		sleep(1);
	}
	return EXIT_SUCCESS;
}

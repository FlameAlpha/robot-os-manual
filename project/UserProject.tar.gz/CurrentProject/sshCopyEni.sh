scp ./eni.xml root@192.168.0.99:/opt/ECMworkspace_64

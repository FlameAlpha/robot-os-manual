/*
 * RobotInterface.h
 *
 *  Created on: 2019-3-27
 *      Author: hanbing
 */

#ifndef ROBOTINTERFACE_H_
#define ROBOTINTERFACE_H_

//====================================axis====================================
/*get robot or addition axis angle for one axis
 * ecHName: subset name
 * axis_ID: subset axis ID
 *
 * return angle (rad)
 * */
extern double axis_getposition_angle(char* ecHName,int axis_ID);

/*get robot or addition axis target angle for one axis
 * ecHName: subset name
 * axis_ID: subset axis ID
 *
 * return angle (rad)
 * */
extern double axis_getposition_angle_target(char* ecHName,int axis_ID);

/*get robot or addition axis velocity for one axis
 * ecHName: subset name
 * axis_ID: subset axis ID
 *
 * return velocity (rad/s)
 * */
extern double axis_getvelocity_angular(char* ecHName,int axis_ID);

/*get robot or addition axis torque for one axis
 * ecHName: subset name
 * axis_ID: subset axis ID
 *
 * return torque
 * */
extern double axis_gettorque_torque(char* ecHName,int axis_ID);

/*set robot or addition axis angle for one axis
 * ecHName: subset name
 * q: target angle(rad)
 * axis_ID: subset axis ID
 * */
extern void axis_setposition_angle(char* ecHName, double q, int axis_ID);

/*set robot or addition axis velocity for one axis
 * ecHName: subset name
 * qv: target velocity(rad/s)
 * axis_ID: subset axis ID
 * */
extern void axis_setvelocity_angular(char* ecHName, double qv, int axis_ID);

/*set robot or addition axis torque for one axis
 * ecHName: subset name
 * tor: target torque
 * axis_ID: subset axis ID

 * */
extern void axis_settorque_torque(char* ecHName, double tor, int axis_ID);

/*get analog value
 * ecHName: subset name
 * id_index: value index(0,1,2,...)
 * return analog value
 * */
extern double getai_physics(char* ecHName,int id_index);

/*set analog value
 * ecHName: subset name
 * ao: analog value
 * id_index: value index(0,1,2,...)

 * */
extern void setao_physics(char* ecHName, double ao, int id_index);

//====================================robot====================================
/*get robot or addition axis angle
 * ecHName: subset name
 * angle:  return angle(rad)
 * */
extern void robot_getposition_angle(char* ecHName, double* angle);

/*get robot or addition axis tartet angle
 * ecHName: subset name
 * angle:  return  target angle(rad)
 * */
extern void robot_getposition_angle_target(char* ecHName, double* angle);

/*get robot or addition axis velocity
 * ecHName: subset name
 * angular:  return velocity(rad/s)
 * */
extern void robot_getvelocity_angular(char* ecHName, double* angular);

/*get robot or addition axis torque
 * ecHName: subset name
 * torque:  return torque
 * */
extern void robot_gettorque_torque(char* ecHName, double* torque);

/*set robot or addition axis target angle
 * ecHName: subset name
 * angle:  target angle(rad)
 * */
extern void robot_setposition_angle(char* ecHName, double* angle);

/*set robot or addition axis target velocity
 * ecHName: subset name
 * angular:  target velocity(rad/s)
 * */
extern void robot_setvelocity_angular(char* ecHName, double* angular);

/*set robot or addition axis target torque
 * ecHName: subset name
 * angle:  target torque
 * */
extern void robot_settorque_torque(char* ecHName, double* torque);


#endif /* ROBOTINTERFACE_H_ */
